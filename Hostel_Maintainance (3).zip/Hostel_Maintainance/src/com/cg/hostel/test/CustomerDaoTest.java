package com.cg.hostel.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.hostel.bean.CustomerBean;
import com.cg.hostel.bean.HostelBean;
import com.cg.hostel.dao.CustomerDaoImpl;
import com.cg.hostel.exception.CustomerException;
import com.cg.hostel.exception.HostelException;

public class CustomerDaoTest {
	static CustomerDaoImpl dao;
	static CustomerBean customer;
	static HostelBean hostel;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new CustomerDaoImpl();
		customer = new CustomerBean();
		hostel=new HostelBean();
	}
	@Test
	public void testregisterHostel1() throws HostelException {
		assertNotNull(dao.registerHostel(hostel));
	}

	@Test
	public void testAddCustomerDetails() throws CustomerException {

		assertNotNull(dao.addCustomer(customer));

	}

	/************************************
	 * Test case for addCustomer()
	 * 
	 ************************************/

	@Ignore
	@Test
	public void testAddCustomerDetails1() throws CustomerException {
		// increment the number next time you test for positive test case
		assertEquals(101, dao.addCustomer(customer));
	}

	/************************************
	 * Test case for addCustomer()
	 * 
	 ************************************/

	@Test
	public void testAddCustomerDetails2() throws CustomerException {

		customer.setCustomerName("Shashwathi");
		customer.setPhoneNumber("9874523690");
		customer.setAddress("Thirupathi");
		customer.setGraudianName("sundaram");
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addCustomer(customer)) > 100);

	}

	/********************************************
	 * Test case for retrieveAll()
	 ************************************************/
	@Test
	public void testViewAll() throws CustomerException {
		assertNotNull(dao.retrieveAll());
	}

	/****************************************************
	 * Test case for viewCustomerDetails()
	 * @throws SQLException 
	 ******************************************************/

	@Test
	public void testById() throws CustomerException, SQLException {
		assertNotNull(dao.viewCustomerDetails("110"));
	}
	

	/************************************
	 * Test case for registerHostel()
	 * 
	 ************************************/

	@Test
	public void testregisterHostel() throws HostelException {

		hostel.setNestName("AlphaHostel");
		hostel.setPhoneNumber("9876596574");
		hostel.setNestLocation("Siruseri");
		hostel.setRent(5500);
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.registerHostel(hostel)) > 1);

	}
	
	/********************************************
	 * Test case for viewHostel()
	 * @throws CustomerException 
	 ************************************************/
	@Test
	public void testviewHostel() throws HostelException, CustomerException {
		assertNotNull(dao.viewHostel());
	}
	
	@Test
	public void testByName() throws HostelException, SQLException{
		assertNotNull(dao.getHostelName("3"));
	}


	@Ignore
	@Test
	public void testById1() throws CustomerException, SQLException {
		assertEquals("TestName", dao.viewCustomerDetails("110").getCustomerName());
	}


}
