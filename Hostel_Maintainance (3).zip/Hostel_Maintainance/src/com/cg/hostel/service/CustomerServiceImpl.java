package com.cg.hostel.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.hostel.bean.CustomerBean;
import com.cg.hostel.bean.HostelBean;
import com.cg.hostel.dao.CustomerDao;
import com.cg.hostel.dao.CustomerDaoImpl;
import com.cg.hostel.exception.CustomerException;
import com.cg.hostel.exception.HostelException;

public class CustomerServiceImpl implements CustomerService
{
	CustomerDao customerDao=new CustomerDaoImpl();
	
	//------------------------ 1. Hostel Maintainance --------------------------
		/*******************************************************************************************************
		 - Function Name	:	viewHostel()
		 - Input Parameters	:	-
		 - Return Type		:	List
		 - Throws			:  	HostelException, CustomerException
		 - Author			:	Sai Sowmya 
		 - Creation Date	:	18/12/2018
		 - Description		:	viewing the hostel
		 ********************************************************************************************************/

	@Override
	public List viewHostel() throws HostelException, CustomerException {        //to view the available hostel in the city
		customerDao=new CustomerDaoImpl();
		List<HostelBean>hostelList=null;
		hostelList=customerDao.viewHostel();
		return hostelList;
	}
	
	//------------------------ 1. Hostel Maintainence --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addCustomer(CustomerBean customer)
			 - Input Parameters	:	CustomerBean customer
			 - Return Type		:	String
			 - Throws			:  	CustomerException
			 - Author			:	Sai Sowmya
			 - Creation Date	:	18/12/2018
			 - Description		:	Adding Customer
			 ********************************************************************************************************/


	@Override
	public String addCustomer(CustomerBean customer) throws CustomerException {     //to add customer for booking the hostel
		String roomSeq;
		roomSeq=customerDao.addCustomer(customer);
		return roomSeq;
	}
	
	
	//------------------------ 1. Hostel Maintainence --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewCustomerDetails(String roomNumber)
	 - Input Parameters	:	String roomNumber
	 - Return Type		:	CustomerBean
	 - Throws			:  	CustomerException
	 - Author			:	Sai Sowmya
	 - Creation Date	:	18/12/2018
	 - Description		:	Viewing Customer
	 ********************************************************************************************************/

	@Override
	public CustomerBean viewCustomerDetails(String roomNumber) throws CustomerException, SQLException {            //to view the customer details of that particular room
		System.out.println(roomNumber);
		CustomerBean customerBean=new CustomerBean();
		customerBean=customerDao.viewCustomerDetails(roomNumber);
		return customerBean;
	}

	
	//------------------------ 1. Hostel Maintainence --------------------------
		/*******************************************************************************************************
		 - Function Name	:	retrieveAll()
		 - Input Parameters	:	-
		 - Return Type		:	List
		 - Throws			:  	CustomerException
		 - Author			:	Sai Sowmya
		 - Creation Date	:	18/12/2018
		 - Description		:	retriving all Customer details
		 ********************************************************************************************************/
	@Override
	public List retrieveAll() throws CustomerException {              //to display all the details of customer details of all hostels
		customerDao=new CustomerDaoImpl();
		List<CustomerBean> customerList=null;
		customerList=customerDao.retrieveAll();
		return customerList;
	}
	
	/*******************************************************************************************************
	 - Function Name	: validateCustomer(CustomerBean customer)
	 - Input Parameters	: CustomerBean customer
	 - Return Type		: boolean
	 - Author	      	: Sai Sowmya
	 - Creation Date	: 18/12/2018
	 - Description		: validates the customer object
	 ********************************************************************************************************/

	public boolean validateCustomer(CustomerBean customer) {         // to validate the details which are all entered by the customer
		List<String> validationErrors=new ArrayList<String>();
		if(!(isValidName(customer.getCustomerName())))
		{
			validationErrors.add("\n Customer Name should be in alphabets and in minimum 4 characters long!\n");
		}
		if(!(isValidPhoneNumber(customer.getPhoneNumber())))
		{
			validationErrors.add("\nphone number should be in 10 digits");
		}
		if(!(isValidAddress(customer.getAddress())))
		{
			validationErrors.add("\n Address should be greater than 5 characters!\n");
		}
		if(!(isValidGraudianName(customer.getGraudianName())))
		{
			validationErrors.add("\nDonor name should be Alphabets and minimum 5 characters long!\n");
		}
		if(!validationErrors.isEmpty())
			return false;
		
		return true;
	}

	private boolean isValidGraudianName(String graudianName) {            //function to validate graudian name
		Pattern namePattern=Pattern.compile("^[A-Za-z]{5,}$");
		Matcher nameMatcher=namePattern.matcher(graudianName);
		return nameMatcher.matches();
		
	}

	private boolean isValidAddress(String address) {                         //function to validate address
		return (address.length() > 5);
		
	}

	private boolean isValidPhoneNumber(String phoneNumber) {                      //function to validate phone number
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
	}

	private boolean isValidName(String customerName) {                       //function to validate customer name
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(customerName);
		return nameMatcher.matches();
	}

	@Override
	public String registerHostel(HostelBean hostel) throws HostelException {
		String hosSeq;
		hosSeq=customerDao.registerHostel(hostel);
		return hosSeq;
		
	}

	@Override
	public HostelBean getHostelName(String allocate) throws HostelException, SQLException {
		System.out.println(allocate);
		HostelBean hostelBean=new HostelBean();
		hostelBean=customerDao.getHostelName(allocate);
		return hostelBean;
		
	}

}
