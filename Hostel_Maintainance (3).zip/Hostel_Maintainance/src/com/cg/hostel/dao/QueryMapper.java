package com.cg.hostel.dao;

public interface QueryMapper {
	public static final String insert_customer="insert into Cust_Details values(roomnum_sequence.nextVal,?,?,?,?,SYSDATE)";
	public static final String retrieve_customer="select * from cust_details where roomNumber=?";
	public static final String list_all_customer="select * from cust_details";
	public static final String add_hostel="insert into nest_Details values(nestid_seq.nextVal,?,?,?,?)";
	public static final String get_hostel_name="select * from nest_details where nestId=?";
	public static final String view_hostel="select * from nest_details";
	public static final String get_max_nestId="select nestid_seq.CURRVAL FROM DUAL";
	public static final String get_max_roomNumber="select roomnum_sequence.CURRVAL FROM DUAL";
}
